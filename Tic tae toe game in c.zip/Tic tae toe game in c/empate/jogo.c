/*
COMO COMPILAR:
gcc -o jogo.out funcao.c jogo.c
EXECUTAR:
./jogo.out
obs: voce pode usar os casos testes projetados (que estao na pasta junto com o programa) para testar:
./jogo.out <ganhalinha5
Direitos Reservados: © Maycon Aguiar Teixeira da Silva.
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include"biblioteca.h"

int main(){
  char mat[TAM][TAM];
  int i=0,j=0,k=0,m=0;
  printf("BEM VINDO AO JOGO DA VELHA!!\n\n\tVeja as regras do jogo:\n1. Destina-se a dois jogadores, a primeira jogada sempre eh do 'X' e segunda do 'O'.\n2 Tem tres tipos de modo de jogo: Player 1 vs Player2, Player1 vs Computador e Computador vs Computador.\n3. O jogo é feito alternadamente, uma marcacao por vez, nos devidos espacos vazios.\n4. A dimensao n deve estar entre 4 a 9.\nO objetivo eh conseguir n CIRCULOS ou n X em linha, horizontal, vertical ,diagonal primaria, diagonal secundaria ou sub-diagonal (sub-diagonais que tangenciam as bordas do tabuleiro e se estendem em uma nova direcao ate somarem a dimensao).\n\n\tBoa sorte\n\n");
  int dim;
  puts("Entre com a dimensao da matriz: ");
  scanf("%d",&dim);
  while(dim<4||dim>9){
    printf("A dimensao deve ser entre 4 e 9\nDigite novamente por favor: ");
    scanf("%d",&dim);
  }
  for(i=0;i<dim;i++){ // preenchimento da matriz com * que corresponde a posição vazia
    for(j=0;j<dim;j++){//preenche todas a posição com '*'
      mat[i][j]='*';
    }
  }
  printf("\nDigite 1 para Player 1 vs Player 2, 2 para Player vs computador e 3 para computador vs computador.\n");
  scanf("%d",&i); // o usuario digita o o tipo de jogo
  while(i<1 || i>dim){//testa se o tipo de jogo é valido ou não
    printf("Invalido, escolha novamente");
    scanf("%d",&i);
  }
  switch(i){//para escolher o tipo de jogo
    case 1: // case usado para selecionar tipo de jogo, neste caso é usado o modo Player vs Player
    do{
      if(k%2==0){// Testa a vez do jogador: se o resto for igual a 0 a vez do jogador 'x' se for diferente é a vez do jogador 'o'
        /*Imprime o jogo*/
        for(i=0;i<dim;i++){
          for(j=0;j<dim;j++){
            printf("%c| ",mat[i][j]);
          }
          printf("\n");
          printf("\n");
        }
        printf("Diga, respectivamente: a linha e coluna que deseja marcar.\n");
        scanf("%d%d",&i,&j);
        while((mat[i-1][j-1]=='x') || (mat[i-1][j-1]=='o')|| (i<1 || i>dim) || (j<1 || j>dim)){/*Verifica se a posição solicitada já foi marcada e se o eh valida*/
          printf("Por favor, digite novamente a linha e a coluna que voce deseja marcar.\n");
          scanf("%d%d",&i,&j);
        }
        mat[i-1][j-1]='x';//preenche com o 'x' a posição desejada
        m++;//incrementa o 'm' para o teste abaixo
        if (m>=(dim*2)-1){//Só faz os testes abaixo apartir da jogada dim+2
          if(ganhou(mat,dim,'x')){
            for(i=0;i<dim;i++){
              for(j=0;j<dim;j++){
                printf("%c| ",mat[i][j]);
              }
              printf("\n");
              printf("\n");
            }
            printf("Parabens!!! Player 1 voce venceu!!!\n");
            break;
          }
          if(m==dim*dim){
          printf("\n\nEMPATE\n\n");
          break;
          }
        }
      }
      else{//vez do jogador 'o'
      for(i=0;i<dim;i++){
        for(j=0;j<dim;j++){
          printf("%c| ",mat[i][j]);
        }
        printf("\n");
        printf("\n");
      }
        printf("Diga, respectivamente: a linha e coluna que deseja marcar.\n");
        scanf("%d%d",&i,&j);
        while((mat[i-1][j-1]=='x') || (mat[i-1][j-1]=='o')|| (i<1 || i>dim) || (j<1 || j>dim)){/*Verifica se a posição solicitada já foi marcada e se o se o jogador digita posçoes que não existem*/
          printf("Por favor digite novamente a linha e a coluna qe voce deseja marcar.\n");
          scanf("%d%d",&i,&j);
        }
        mat[i-1][j-1]='o';//preenche com o 'x' a posição desejada
        m++;//incrementa o 'm' para o proximo teste
        if (m>=(dim*2)-1){//Só faz os testes abaixo apartir da jogada dim+2
          if(ganhou(mat,dim,'o')){
            for(i=0;i<dim;i++){
              for(j=0;j<dim;j++){
                printf("%c| ",mat[i][j]);
              }
              printf("\n");
              printf("\n");
            }
            printf("Parabens!!! Player 2 voce venceu!!!\n");
            break;
          }
          if(m==dim*dim){
          printf("\n\nEMPATE\n\n");
          break;
          }
        }
      }
      k++;//incrementa o 'k' para o primeiro teste que verá de qual jogador é a vez
      }while(1);//mantem o jogo rodando
    break;
    case 2: // case usado para selecionar tipo de jogo, neste case é usado o modo Player vs computador
    do{
      if(k%2==0){// Testa a vez do jogador: se o resto for igual a 0 a vez do jogador 'x' se for diferente é a vez do jogador 'o'
      for(i=0;i<dim;i++){
        for(j=0;j<dim;j++){
          printf("%c| ",mat[i][j]);
        }
        printf("\n");
        printf("\n");
      }
        printf("Diga, respectivamente: a linha e coluna que deseja marcar.\n");
        scanf("%d%d",&i,&j);
        while((mat[i-1][j-1]=='x') || (mat[i-1][j-1]=='o')|| (i<1 || i>dim) || (j<1 || j>dim)){/*Verifica se a posição solicitada já foi marcada e se o se o jogador digita posçoes que não existem*/
          printf("Por favor digite novamente a linha e a coluna qe voce deseja marcar.\n");
          scanf("%d%d",&i,&j);
        }
        mat[i-1][j-1]='x';
        m++;
        if (m>=(dim*2)-1){//Só faz os testes abaixo apartir da jogada dim+2
            if(ganhou(mat,dim,'x')){
              for(i=0;i<dim;i++){
                for(j=0;j<dim;j++){
                  printf("%c| ",mat[i][j]);
                }
                printf("\n");
                printf("\n");
              }
              printf("Parabens!!! Player 1 voce venceu!!!\n");
              break;
            }
            if(m==dim*dim){
            printf("\n\nEMPATE\n\n");
            break;
            }
           }
      }
      else{//vez do computador
        for(i=0;i<dim;i++){
          for(j=0;j<dim;j++){
            printf("%c| ",mat[i][j]);
          }
          printf("\n");
          printf("\n");
        }
        printf("Computador mexeu.\n");
        srand(time(NULL));//comando para sorteio
        i = rand()%dim;//sorteia uma posição i
        j = rand()%dim;//sorteia uma posição j
        while((mat[i][j]=='x') || (mat[i][j]=='o')){//testa para se a posição desejada já esta preenchida se ja estiver sorteia novamente
        i = rand()%dim;
        j = rand()%dim;
        }
        mat[i][j]='o';//preenche a posição desejada com 'o'
        m++;
          if (m>=(dim*2)-1){//Só faz os testes abaixo apartir da jogada dim+2
            if(ganhou(mat,dim,'o')){
              for(i=0;i<dim;i++){
                for(j=0;j<dim;j++){
                  printf("%c| ",mat[i][j]);
                }
                printf("\n");
                printf("\n");
              }
              printf("O computador venceu!!!\n");
              break;
            }
            if(m==dim*dim){
            printf("\n\nEMPATE\n\n");
            break;
            }
        }
      }
      k++;
      }while(1);//mantem o jogo rodando
    break;
    case 3: // case usado para selecionar tipo de jogo, neste case é usado o modo computador vs computador
    do{
      if(k%2==0){
        for(i=0;i<dim;i++){
          for(j=0;j<dim;j++){
            printf("%c| ",mat[i][j]);
          }
          printf("\n");
          printf("\n");
        }
      printf("Computador 1 mexeu.\n");
      srand(time(NULL));
      i = rand()%dim;
      j = rand()%dim;
      while((mat[i][j]=='x') || (mat[i][j]=='o')){/*Verifica se a posição solicitada já foi marcada*/
      i = rand()%dim;
      j = rand()%dim;
      }
      mat[i][j]='x';
      m++;
      if (m>=(dim*2)-1){
        if(ganhou(mat,dim,'x')){
          for(i=0;i<dim;i++){
            for(j=0;j<dim;j++){
              printf("%c| ",mat[i][j]);
            }
            printf("\n");
            printf("\n");
          }
          printf("O computador 1 venceu!!!\n");
          break;
        }
      if(m==dim*dim){
      printf("\n\nEMPATE\n\n");
      break;
      }
      }
      }
      else{
        for(i=0;i<dim;i++){
          for(j=0;j<dim;j++){
            printf("%c| ",mat[i][j]);
          }
          printf("\n");
          printf("\n");
        }
      printf("Computador 2 mexeu .\n");
      srand(time(NULL));
      i = rand()%dim;
      j = rand()%dim;
      while((mat[i][j]=='x') || (mat[i][j]=='o')){/*Verifica se a posição solicitada já foi marcada*/
      i = rand()%dim;
      j = rand()%dim;
      }
      mat[i][j]='o';
      m++;
        if (m>=(dim*2)-1){
          if(ganhou(mat,dim,'o')){
            printf("O computador 2 venceu!!!\n");
            break;
          }
        if(m==dim*dim){
        printf("\n\nEMPATE\n\n");
        break;
        }
      }
      }
      k++;
    }while(1);

    }

  return 0;
}
