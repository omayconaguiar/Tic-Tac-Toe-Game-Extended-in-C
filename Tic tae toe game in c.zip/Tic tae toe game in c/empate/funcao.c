#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include"biblioteca.h"

#define TAM 9

//vem da esquerda ou direita e bate em baixo espelhando para o lado contrario que partiu
int verificabaixo( char mat[TAM][TAM], int dim, char verificador )
{
    //contador começa em zero
    int marcou = 0;
    //indice de linha começa com 1
    int i = 1;
    //indice de coluna começa com 0
    int j = 0;
    int k;

    // Verifica se a coluna esquerda tem algum x
    while( i < dim-1 )
    {
        //se a posicao for diferente do caractere incrementa linha ate chegar na do usuario
        if( mat[i][j] != verificador )
        {
            ++i;
            continue;
        }
        int l = 1;
        // Se tiver verifica a diagonal especial correspondente
        for( int k = 0 ; k < dim ; ++k, ++j, i += l, ++marcou )
        {
            //condicao que esta na penultima linha
            if( i == dim - 1 )
            {   //assume novo valor para l que sera adicionado ao i (dependendo da operação arimetica)
                l = -1;
            }
            //se for diferente acabou
            if( mat[i][j] != verificador )
            {   //retorna o contador que deve ser igual a dimensao
                return marcou;
            }
        }
    }
    //retorna o contador que deve ser igual a dimensao
    return marcou;

  }

  //vem da esquerda ou direita e bate em cima espelhando para o lado contrario que partiu
int verificacima( char mat[TAM][TAM], int dim, char verificador ){

  int marcou = 0;
  int i = 1;
  int j = 0;
    int k;
    // bate m cima
    while( i < dim-1 )
    {
        if( mat[i][j] != verificador )
        {
            ++i;
            continue;
        }
        int l = 1;
        // Se tiver verifica a diagonal especial correspondente
        for( int k = 0 ; k < dim ; ++k, ++j, i -= l, ++marcou )
        {    //condicao que esta na primeira linha
            if( i == 0 )
            {   //assume novo valor para l que sera adicionado ao i (dependendo da operação arimetica)
                l = -1;
            }
            //se for diferente acabou
            if( mat[i][j] != verificador )
            {   //retorna o contador que deve ser igual a dimensao
                return marcou;
            }
        }
    }
    //retorna o contador que deve ser igual a dimensao
    return marcou;
}

//vem de cima ou de baixo e bate na direita espelhando para o lado contrario que partiu
int verificadireita( char mat[TAM][TAM], int dim, char verificador ){
  int marcou = 0;
  int i = 1;
  int j = 0;
  int k;
    //bate na direita
    while( i < dim-1 )
    {
        if( mat[j][i] != verificador )
        {
            ++i;
            continue;
        }
        int l = 1;
        // Se tiver verifica a diagonal especial correspondente
        for( int k = 0 ; k < dim ; ++k, ++j, i += l, ++marcou )
        {   //condicao que esta na penultima linha
            if( i == dim-1 )
            {   //assume novo valor para l que sera adicionado ao i (dependendo da operação arimetica)
                l = -1;
            }
            //se for diferente acabou
            if( mat[j][i] != verificador )
            {   //retorna o contador que deve ser igual a dimensao
                return marcou;
            }
        }
    }
    //retorna o contador que deve ser igual a dimensao
    return marcou;
}
//vem de cima ou de baixo e bate na esquerda espelhando para o lado contrario que partiu
int verificaesquerda( char mat[TAM][TAM], int dim, char verificador ){
  int marcou = 0;
  int i = 1;
  int j = 0;
  int k;
  //bate na esquerda
    while( i < dim-1 )
    {
        if( mat[j][i] != verificador )
        {
            ++i;
            continue;
        }
        int l = 1;
        // Se tiver verifica a diagonal especial correspondente
        for( int k = 0 ; k < dim ; ++k, ++j, i -= l, ++marcou )
        {   //condicao que esta na primeira linha
            if( i == 0 )
            {   //assume novo valor para l que sera adicionado ao i (dependendo da operação arimetica)
                l = -1;
            }
            //se for diferente acabou
            if( mat[j][i] != verificador)
            {   //retorna o contador que deve ser igual a dimensao
                return marcou;
            }
        }
    }
    //retorna o contador que deve ser igual a dimensao
    return marcou;
  }


//verifica casos classicos do jogo da velha: linhas, colunas, diagonal principal e secundaria
int verificaclassico( char mat[TAM][TAM], int dim, char verificador ){
  int i,j;
  int ganhalinha=0,ganhacoluna=0,ganhadiagprin=0,ganhadiagsec=0;
  //outra parte
  for(i=0;i<dim;i++) {
    for(j=0;j<dim;j++) {

      //verifica linhas
      if(mat[i][j]==verificador)
        ganhalinha++;
      //verifica colunas
      if(mat[j][i]==verificador)
      ganhacoluna++;
      //verifica diagonal principal
       if(mat[j][j]==verificador)
       ganhadiagprin++;
       //verifica diagonal secundaria
       if (mat[j][dim-1-j]==verificador)
       ganhadiagsec++;
       //se contadores forem iguais a dimensao retorna true
        if(ganhalinha==dim||ganhacoluna==dim||ganhadiagprin==dim||ganhadiagsec==dim)
          return 1;
      }
      //zera contador pra proximas condicoes
      ganhalinha=0;ganhacoluna=0;ganhadiagprin=0;ganhadiagsec=0;
  }

  return 0;

}


//funcao que verifica que se retorno da outras funcoes é igual a dimensao retorna um ou outro como verdade
int ganhou( char mat[TAM][TAM], int dim, char verificador ){
  //verifica se casos especiais sao verdaeiros sendo o verificador como o 'X' ou 'O'
  int diagespecial = verificabaixo(mat, dim, verificador) == dim ||
                     verificacima(mat, dim, verificador) ==dim||
                     verificaesquerda(mat, dim, verificador)==dim||
                     verificadireita(mat, dim, verificador)==dim;
  //verifica caso classico como verdaeiro
  int classico= verificaclassico(mat, dim, verificador);
  //retorna uma condicao ou outra
  return diagespecial || classico;

}
