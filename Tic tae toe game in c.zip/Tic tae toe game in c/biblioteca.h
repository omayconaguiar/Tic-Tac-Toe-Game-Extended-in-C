#include <time.h>

#define TAM 9

//vem da esquerda ou direita e bate em baixo espelhando para o lado contrario que partiu
int verificabaixo( char mat[TAM][TAM], int dim, char verificador );
//vem da esquerda ou direita e bate em cima espelhando para o lado contrario que partiu
int verificacima( char mat[TAM][TAM], int dim, char verificador );
//vem de cima ou de baixo e bate na direita espelhando para o lado contrario que partiu
int verificadireita( char mat[TAM][TAM], int dim, char verificador );
//vem de cima ou de baixo e bate na esquerda espelhando para o lado contrario que partiu
int verificaesquerda( char mat[TAM][TAM], int dim, char verificador );
//verifica casos classicos do jogo da velha: linhas, colunas, diagonal principal e secundaria
int verificaclassico( char mat[TAM][TAM], int dim, char verificador );
//funcao que verifica que se retorno da outras funcoes é igual a dimensao retorna um ou outro como verdade
int ganhou( char mat[TAM][TAM], int dim, char verificador );
